//! CPU state container and execution loop.

mod execute;

pub use execute::Cpu;
