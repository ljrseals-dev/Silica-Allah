//! Main CPU state and fetch-decode-execute loop.

use crate::isa::decoder::{DecodedInsn, Decoder};
use crate::isa::registers::RegisterFile;
use crate::isa::semantics;
use crate::memory::FlatMemory;

/// Architectural CPU state for the ISA-level simulator.
pub struct Cpu {
    pub regs: RegisterFile,
    pub mem: FlatMemory,
    pub decoder: Decoder,
    /// Simple halt flag for the educational loop.
    pub halted: bool,
    /// Instruction counter (architectural steps only).
    pub steps: u64,
}

impl Default for Cpu {
    fn default() -> Self {
        Self {
            regs: RegisterFile::default(),
            mem: FlatMemory::new(),
            decoder: Decoder::default(),
            halted: false,
            steps: 0,
        }
    }
}

impl Cpu {
    pub fn new() -> Self {
        Self::default()
    }

    /// Load a sequence of instruction words at the given address and set PC.
    pub fn load_program(&mut self, base: u64, code: &[u32]) {
        self.mem.load_code(base, code);
        self.regs.pc = base;
    }

    /// Execute a single instruction (fetch → decode → execute).
    ///
    /// PC is advanced by 4 for non-branch instructions.
    /// Branches update PC themselves inside the semantic function.
    pub fn step(&mut self) -> Result<(), String> {
        if self.halted {
            return Err("CPU is halted".into());
        }

        let pc = self.regs.pc;
        let word = self.mem.read_u32_le(pc);
        let insn = self.decoder.decode(word);

        // Default PC advance; branches will overwrite.
        self.regs.pc = pc.wrapping_add(4);

        let cont = semantics::execute_insn(&insn, &mut self.regs, &mut self.mem);
        self.steps += 1;

        if !cont {
            self.halted = true;
        }

        // Special educational halt: all-zero instruction treated as stop
        if matches!(insn, DecodedInsn::Unimplemented { raw: 0 }) {
            self.halted = true;
        }

        Ok(())
    }

    /// Run until halted or a maximum number of steps.
    pub fn run(&mut self, max_steps: u64) -> Result<u64, String> {
        let start = self.steps;
        while !self.halted && (self.steps - start) < max_steps {
            self.step()?;
        }
        Ok(self.steps - start)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn nop_sequence() {
        let mut cpu = Cpu::new();
        // Three NOPs followed by a zero word (halt)
        cpu.load_program(0x1000, &[0xD503_201F, 0xD503_201F, 0xD503_201F, 0]);
        let steps = cpu.run(10).unwrap();
        assert_eq!(steps, 4); // 3 NOPs + the zero word
        assert!(cpu.halted);
    }
}
