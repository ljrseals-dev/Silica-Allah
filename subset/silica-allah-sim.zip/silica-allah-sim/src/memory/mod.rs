//! Memory subsystem (architectural flat model only).

mod flat_memory;

pub use flat_memory::FlatMemory;
