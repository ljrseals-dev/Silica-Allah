//! Simple flat 64-bit address space.
//!
//! No caches, no MMU translation, no device model — pure architectural memory
//! for ISA-level experimentation.

use std::collections::BTreeMap;

/// Sparse flat memory. Only written pages/bytes are stored.
#[derive(Default)]
pub struct FlatMemory {
    data: BTreeMap<u64, u8>,
}

impl FlatMemory {
    pub fn new() -> Self {
        Self {
            data: BTreeMap::new(),
        }
    }

    /// Read a single byte. Uninitialized locations return 0.
    #[inline]
    pub fn read_u8(&self, addr: u64) -> u8 {
        self.data.get(&addr).copied().unwrap_or(0)
    }

    /// Write a single byte.
    #[inline]
    pub fn write_u8(&mut self, addr: u64, val: u8) {
        if val == 0 {
            self.data.remove(&addr);
        } else {
            self.data.insert(addr, val);
        }
    }

    /// Read little-endian u32 (instruction fetch).
    #[inline]
    pub fn read_u32_le(&self, addr: u64) -> u32 {
        let b0 = self.read_u8(addr) as u32;
        let b1 = self.read_u8(addr.wrapping_add(1)) as u32;
        let b2 = self.read_u8(addr.wrapping_add(2)) as u32;
        let b3 = self.read_u8(addr.wrapping_add(3)) as u32;
        b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
    }

    /// Write little-endian u32.
    #[inline]
    pub fn write_u32_le(&mut self, addr: u64, val: u32) {
        self.write_u8(addr, (val & 0xff) as u8);
        self.write_u8(addr.wrapping_add(1), ((val >> 8) & 0xff) as u8);
        self.write_u8(addr.wrapping_add(2), ((val >> 16) & 0xff) as u8);
        self.write_u8(addr.wrapping_add(3), ((val >> 24) & 0xff) as u8);
    }

    /// Read little-endian u64.
    #[inline]
    pub fn read_u64_le(&self, addr: u64) -> u64 {
        let lo = self.read_u32_le(addr) as u64;
        let hi = self.read_u32_le(addr.wrapping_add(4)) as u64;
        lo | (hi << 32)
    }

    /// Write little-endian u64.
    #[inline]
    pub fn write_u64_le(&mut self, addr: u64, val: u64) {
        self.write_u32_le(addr, (val & 0xffff_ffff) as u32);
        self.write_u32_le(addr.wrapping_add(4), ((val >> 32) & 0xffff_ffff) as u32);
    }

    /// Load a slice of instruction words starting at `addr`.
    pub fn load_code(&mut self, addr: u64, words: &[u32]) {
        for (i, &w) in words.iter().enumerate() {
            self.write_u32_le(addr + (i as u64) * 4, w);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_u32() {
        let mut mem = FlatMemory::new();
        mem.write_u32_le(0x1000, 0xD503_201F); // NOP
        assert_eq!(mem.read_u32_le(0x1000), 0xD503_201F);
    }
}
