//! Silica-Allah Simulator — ISA-level AArch64 architectural core.
//!
//! **Scope**: Publicly documented AArch64 behavior only.
//! See `docs/limitations.md`.

pub mod cpu;
pub mod isa;
pub mod memory;

pub use cpu::Cpu;
pub use isa::registers::{Pstate, RegisterFile};
pub use memory::FlatMemory;
