//! Architectural register file for AArch64 (public ISA only).
//!
//! Models:
//! - 31 general-purpose 64-bit registers X0–X30 + SP/XZR
//! - 32 × 128-bit SIMD&FP registers V0–V31
//! - Program Counter (PC)
//! - PSTATE flags (NZCV + selected control bits)
//!
//! No proprietary system registers or Apple-specific state.

use std::fmt;

/// PSTATE (Process State) — architectural flags only.
#[derive(Clone, Copy, Debug, Default)]
pub struct Pstate {
    pub n: bool, // Negative
    pub z: bool, // Zero
    pub c: bool, // Carry
    pub v: bool, // Overflow
    // Selected control bits (simplified for ISA-level model)
    pub d: bool, // Debug mask
    pub a: bool, // SError mask
    pub i: bool, // IRQ mask
    pub f: bool, // FIQ mask
    pub el: u8,  // Exception Level (0–3)
    pub sp: u8,  // Stack pointer select (0 or 1)
}

impl Pstate {
    pub fn nzcv(&self) -> u8 {
        ((self.n as u8) << 3)
            | ((self.z as u8) << 2)
            | ((self.c as u8) << 1)
            | (self.v as u8)
    }

    pub fn set_nzcv(&mut self, nzcv: u8) {
        self.n = (nzcv & 0b1000) != 0;
        self.z = (nzcv & 0b0100) != 0;
        self.c = (nzcv & 0b0010) != 0;
        self.v = (nzcv & 0b0001) != 0;
    }
}

/// Architectural register file.
#[derive(Clone)]
pub struct RegisterFile {
    /// X0–X30 (index 0–30). X31 is handled specially as XZR or SP.
    pub x: [u64; 31],
    /// Stack Pointer (SP_EL0 / SP_ELx depending on PSTATE.SP)
    pub sp: u64,
    /// SIMD&FP registers V0–V31 (128-bit each, stored as two u64)
    pub v: [[u64; 2]; 32],
    /// Program Counter
    pub pc: u64,
    /// Process State
    pub pstate: Pstate,
}

impl Default for RegisterFile {
    fn default() -> Self {
        Self {
            x: [0; 31],
            sp: 0,
            v: [[0; 2]; 32],
            pc: 0,
            pstate: Pstate::default(),
        }
    }
}

impl RegisterFile {
    /// Read Xn (n = 0..30). Reading X31 returns 0 (XZR).
    #[inline(always)]
    pub fn read_x(&self, n: u8) -> u64 {
        if n < 31 {
            self.x[n as usize]
        } else {
            0 // XZR
        }
    }

    /// Write Xn (n = 0..30). Writing X31 is ignored (XZR).
    #[inline(always)]
    pub fn write_x(&mut self, n: u8, val: u64) {
        if n < 31 {
            self.x[n as usize] = val;
        }
        // XZR writes are discarded
    }

    /// Read SP (architectural stack pointer).
    #[inline(always)]
    pub fn read_sp(&self) -> u64 {
        self.sp
    }

    /// Write SP.
    #[inline(always)]
    pub fn write_sp(&mut self, val: u64) {
        self.sp = val;
    }

    /// Read Wn (32-bit view of Xn).
    #[inline(always)]
    pub fn read_w(&self, n: u8) -> u32 {
        self.read_x(n) as u32
    }

    /// Write Wn (zero-extends into Xn).
    #[inline(always)]
    pub fn write_w(&mut self, n: u8, val: u32) {
        self.write_x(n, val as u64);
    }

    /// Read 128-bit Vn as two u64 (low, high).
    #[inline(always)]
    pub fn read_v(&self, n: u8) -> [u64; 2] {
        self.v[n as usize]
    }

    /// Write 128-bit Vn.
    #[inline(always)]
    pub fn write_v(&mut self, n: u8, val: [u64; 2]) {
        self.v[n as usize] = val;
    }
}

impl fmt::Debug for RegisterFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RegisterFile")
            .field("pc", &format_args!("0x{:016x}", self.pc))
            .field("sp", &format_args!("0x{:016x}", self.sp))
            .field("pstate.nzcv", &self.pstate.nzcv())
            .field("pstate.el", &self.pstate.el)
            .finish_non_exhaustive()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn xzr_reads_zero() {
        let rf = RegisterFile::default();
        assert_eq!(rf.read_x(31), 0);
    }

    #[test]
    fn xzr_write_ignored() {
        let mut rf = RegisterFile::default();
        rf.write_x(31, 0xdeadbeef);
        assert_eq!(rf.read_x(31), 0);
    }

    #[test]
    fn basic_x_read_write() {
        let mut rf = RegisterFile::default();
        rf.write_x(0, 42);
        assert_eq!(rf.read_x(0), 42);
        rf.write_w(1, 0xffff_ffff);
        assert_eq!(rf.read_x(1), 0xffff_ffff);
    }
}
