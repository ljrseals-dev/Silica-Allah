//! Per-instruction architectural semantics.
//!
//! Each function implements the state transition defined by the public
//! Arm Architecture Reference Manual for that instruction.
//! Only a minimal subset is present in this educational skeleton.

use crate::isa::decoder::DecodedInsn;
use crate::isa::registers::RegisterFile;
use crate::memory::FlatMemory;

/// Execute one decoded instruction, updating architectural state.
///
/// Returns `true` if execution should continue, `false` if halted (e.g. after a special marker).
pub fn execute_insn(
    insn: &DecodedInsn,
    regs: &mut RegisterFile,
    _mem: &mut FlatMemory,
) -> bool {
    match insn {
        DecodedInsn::Nop => {
            // Architectural NOP: no state change beyond PC advance (handled by caller)
            true
        }

        DecodedInsn::MovReg { rd, rm, sf } => {
            let val = if *sf {
                regs.read_x(*rm)
            } else {
                regs.read_w(*rm) as u64
            };
            if *sf {
                regs.write_x(*rd, val);
            } else {
                regs.write_w(*rd, val as u32);
            }
            true
        }

        DecodedInsn::AddShifted {
            rd,
            rn,
            rm,
            shift,
            imm6,
            sf,
        } => {
            // Simplified: only LSL shift implemented for the skeleton
            let shift_amt = (*imm6 as u32) % if *sf { 64 } else { 32 };
            let op2 = if *sf {
                regs.read_x(*rm).wrapping_shl(shift_amt)
            } else {
                (regs.read_w(*rm) as u64).wrapping_shl(shift_amt)
            };
            // shift encoding is ignored beyond LSL for this skeleton
            let _ = shift;

            if *sf {
                let result = regs.read_x(*rn).wrapping_add(op2);
                regs.write_x(*rd, result);
            } else {
                let result = regs.read_w(*rn).wrapping_add(op2 as u32);
                regs.write_w(*rd, result);
            }
            true
        }

        DecodedInsn::SubShifted {
            rd,
            rn,
            rm,
            shift,
            imm6,
            sf,
        } => {
            let shift_amt = (*imm6 as u32) % if *sf { 64 } else { 32 };
            let op2 = if *sf {
                regs.read_x(*rm).wrapping_shl(shift_amt)
            } else {
                (regs.read_w(*rm) as u64).wrapping_shl(shift_amt)
            };
            let _ = shift;

            if *sf {
                let result = regs.read_x(*rn).wrapping_sub(op2);
                regs.write_x(*rd, result);
            } else {
                let result = regs.read_w(*rn).wrapping_sub(op2 as u32);
                regs.write_w(*rd, result);
            }
            true
        }

        DecodedInsn::B { imm26 } => {
            // PC-relative branch. Imm is in units of 4 bytes.
            // PC has already been advanced by the caller; adjust accordingly.
            let offset = (*imm26 as i64) << 2;
            regs.pc = (regs.pc as i64).wrapping_add(offset) as u64;
            // Note: caller normally does PC += 4; for branches we overwrite.
            true
        }

        DecodedInsn::Ret { rn } => {
            let target = regs.read_x(*rn);
            regs.pc = target;
            true
        }

        DecodedInsn::Unimplemented { raw } => {
            // Educational skeleton: treat as NOP with a warning path
            // In a real simulator this would raise an undefined-instruction exception.
            let _ = raw;
            true
        }
    }
}
