//! ISA module: decoder, registers, and instruction semantics.

pub mod decoder;
pub mod registers;
pub mod semantics;

pub use decoder::{DecodedInsn, Decoder};
pub use registers::{Pstate, RegisterFile};
