//! Lightweight AArch64 instruction decoder skeleton.
//!
//! Designed for high throughput. Only a small subset of encodings is
//! recognized in this educational skeleton; the rest return Unimplemented.
//!
//! Encoding layout follows the public Arm Architecture Reference Manual.
//! Zero external dependencies.

/// High-level decoded instruction categories (subset).
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum DecodedInsn {
    /// ADD (shifted register) — data-processing (register)
    AddShifted {
        rd: u8,
        rn: u8,
        rm: u8,
        shift: u8,
        imm6: u8,
        sf: bool, // 32/64-bit
    },
    /// SUB (shifted register)
    SubShifted {
        rd: u8,
        rn: u8,
        rm: u8,
        shift: u8,
        imm6: u8,
        sf: bool,
    },
    /// MOV (register) — alias of ORR with XZR
    MovReg { rd: u8, rm: u8, sf: bool },
    /// NOP
    Nop,
    /// Branch (unconditional immediate) — simplified
    B { imm26: i32 },
    /// Ret
    Ret { rn: u8 },
    /// Unimplemented encoding (still valid 32-bit word)
    Unimplemented { raw: u32 },
}

/// Stateless decoder. Pure function of the 32-bit encoding.
#[derive(Default)]
pub struct Decoder;

impl Decoder {
    /// Decode a single 32-bit A64 instruction word.
    ///
    /// This is intentionally a fast, table-free skeleton focused on a few
    /// common data-processing and control-flow encodings. Real production
    /// decoders (Disarm, LLVM, etc.) are far more complete.
    #[inline(always)]
    pub fn decode(&self, word: u32) -> DecodedInsn {
        // Data-processing (register) — approximate matching
        // ADD/SUB (shifted register)
        if (word & 0x1F20_0000) == 0x0B00_0000 {
            let sf = (word >> 31) & 1 != 0;
            let op = (word >> 30) & 1; // 0 = ADD, 1 = SUB
            let shift = ((word >> 22) & 0b11) as u8;
            let rm = ((word >> 16) & 0b11111) as u8;
            let imm6 = ((word >> 10) & 0b111111) as u8;
            let rn = ((word >> 5) & 0b11111) as u8;
            let rd = (word & 0b11111) as u8;

            return if op == 0 {
                DecodedInsn::AddShifted {
                    rd,
                    rn,
                    rm,
                    shift,
                    imm6,
                    sf,
                }
            } else {
                DecodedInsn::SubShifted {
                    rd,
                    rn,
                    rm,
                    shift,
                    imm6,
                    sf,
                }
            };
        }

        // MOV (register) / ORR with XZR — simplified
        if (word & 0x7F20_0000) == 0x2A00_0000 {
            let sf = (word >> 31) & 1 != 0;
            let rm = ((word >> 16) & 0b11111) as u8;
            let rn = ((word >> 5) & 0b11111) as u8;
            let rd = (word & 0b11111) as u8;
            if rn == 31 {
                return DecodedInsn::MovReg { rd, rm, sf };
            }
        }

        // NOP (HINT #0)
        if word == 0xD503_201F {
            return DecodedInsn::Nop;
        }

        // Unconditional branch (B)
        if (word & 0xFC00_0000) == 0x1400_0000 {
            let imm26 = (word & 0x03FF_FFFF) as i32;
            // Sign-extend 26-bit immediate
            let imm26 = (imm26 << 6) >> 6;
            return DecodedInsn::B { imm26 };
        }

        // RET
        if (word & 0xFFFF_FC1F) == 0xD65F_0000 {
            let rn = ((word >> 5) & 0b11111) as u8;
            return DecodedInsn::Ret { rn };
        }

        // Everything else
        DecodedInsn::Unimplemented { raw: word }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn decode_nop() {
        let d = Decoder::default();
        assert_eq!(d.decode(0xD503_201F), DecodedInsn::Nop);
    }

    #[test]
    fn decode_ret() {
        let d = Decoder::default();
        // RET (Xn=30)
        let word = 0xD65F_03C0;
        match d.decode(word) {
            DecodedInsn::Ret { rn } => assert_eq!(rn, 30),
            other => panic!("expected Ret, got {:?}", other),
        }
    }
}
