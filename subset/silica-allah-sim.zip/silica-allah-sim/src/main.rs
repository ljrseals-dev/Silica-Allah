//! CLI entry point for the Silica-Allah ISA-level simulator.
//!
//! Zero external dependencies for eternal, easy distribution.

use silica_allah_sim::Cpu;
use std::env;

fn main() {
    let args: Vec<String> = env::args().collect();
    let verbose = args.iter().any(|a| a == "-v" || a == "--verbose");
    let max_steps: u64 = args
        .iter()
        .find_map(|a| a.strip_prefix("--max-steps=").and_then(|s| s.parse().ok()))
        .unwrap_or(1000);

    println!("Silica-Allah Simulator (ISA-level)");
    println!("==================================");
    println!("Scope: Public AArch64 architectural behavior only.");
    println!("This is NOT a model of Apple Silicon micro-architecture.\n");

    let mut cpu = Cpu::new();

    // Demo program: a few NOPs followed by a zero word (educational halt)
    let demo = [
        0xD503_201F, // NOP
        0xD503_201F, // NOP
        0xD503_201F, // NOP
        0x0000_0000, // educational halt marker
    ];

    cpu.load_program(0x0000_0000_0000_1000, &demo);

    match cpu.run(max_steps) {
        Ok(executed) => {
            println!("Executed {} architectural steps.", executed);
            println!("Final PC     = 0x{:016x}", cpu.regs.pc);
            println!("Steps total  = {}", cpu.steps);
            if verbose {
                println!("\nRegister snapshot (X0–X7):");
                for i in 0..8 {
                    println!("  X{:<2} = 0x{:016x}", i, cpu.regs.read_x(i));
                }
            }
        }
        Err(e) => {
            eprintln!("Execution error: {}", e);
            std::process::exit(1);
        }
    }

    println!("\nReminder: see docs/limitations.md for the formal scope of this simulator.");
    println!("Usage: silica-allah-sim [--verbose|-v] [--max-steps=N]");
}
