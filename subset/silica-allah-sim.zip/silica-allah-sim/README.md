# Silica-Allah Simulator (ISA-Level)

An educational, architectural-level AArch64 simulator core written in Rust.

**This project models only the publicly documented Arm AArch64 (Armv8-A / Armv9-A) Instruction Set Architecture.**

## ⚠️ Critical Limitations (Read First)

- **This is NOT a 1:1, cycle-accurate, or silicon-accurate simulation of any Apple Silicon chip** (M-series or otherwise).
- It implements **only** architectural behavior defined in the public Arm Architecture Reference Manuals.
- **No proprietary micro-architecture** is included or claimed: no pipeline timings, cache geometries, branch predictors, Neural Engine weights, Secure Enclave details, undocumented system registers, or Apple-specific extensions.
- Die photographs and public marketing materials provide **zero** usable quantitative parameters for a cycle-accurate or gate-level model.
- Any claim of “1:1 Apple Silicon simulation” from public information alone is infeasible. This project makes no such claim.

See [`docs/limitations.md`](docs/limitations.md) for the full formal scope.

## Purpose

- Study AArch64 instruction semantics offline.
- Experiment with ISA-level state transitions.
- Provide a clean, performant, testable skeleton for further educational research.
- Deliver a zero-dependency codebase that can be mirrored and distributed indefinitely.

## Features (Current Skeleton)

- Architectural register file (X0–X30, SP/XZR, V0–V31, PSTATE, PC)
- Flat memory model
- Instruction decoder skeleton (32-bit A64 encodings)
- Basic fetch-decode-execute loop
- Explicit non-goals and verification notes
- **Zero external runtime dependencies** (stdlib only)

## Building & Running

```bash
cargo build --release
cargo run --release

# Options
cargo run --release -- --verbose
cargo run --release -- --max-steps=500

# Unit + integration tests
cargo test
```

## Performance & Eternal Distribution

- **Zero external dependencies** for the library and binary.  
  No crates.io resolution required at runtime or for basic builds.  
  Ideal for long-term archival, mirroring, and offline use.
- Release profile uses LTO + single codegen unit for high performance.
- Decoder is written for low overhead (inline, table-free educational skeleton).
- Users who want Criterion-style benchmarks can add the dependency themselves; the core stays dependency-free forever.

## Repository Layout

```
silica-allah-sim/
├── Cargo.toml
├── README.md
├── LICENSE
├── docs/
│   ├── limitations.md      # Formal scope & non-goals
│   └── references.md       # Public Arm documentation links only
├── src/
│   ├── lib.rs
│   ├── main.rs
│   ├── isa/
│   │   ├── mod.rs
│   │   ├── decoder.rs
│   │   ├── registers.rs
│   │   └── semantics/
│   ├── memory/
│   │   └── flat_memory.rs
│   └── cpu/
│       ├── mod.rs
│       └── execute.rs
└── tests/
```

## License

MIT OR Apache-2.0

## Disclaimer

This software is provided for educational and research purposes only.  
It is not affiliated with, endorsed by, or derived from any proprietary Apple or Arm implementation beyond the publicly published ISA specifications.
