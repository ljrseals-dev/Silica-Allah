# Limitations and Non-Goals

This simulator is an **architectural (ISA-level) model** of publicly documented AArch64 behavior.  
It is **not** a micro-architectural, cycle-accurate, or silicon-accurate replica of any commercial implementation, including Apple Silicon.

## What This Simulator IS

- A functional model of publicly documented AArch64 instruction semantics.
- A tool for exploring instruction behavior, testing ISA concepts, and educational study.
- Capable of executing small code sequences and producing architectural state changes.
- Designed for high decoder/execution throughput at the ISA level.

## What This Simulator IS NOT

- **A cycle-accurate or gate-level model**  
  It does not model pipeline stages, execution-unit latencies, cache hierarchies, branch predictors, out-of-order execution, or any micro-architectural state.  
  Public Arm documentation does not contain this information.

- **A model of Apple Silicon**  
  It contains **zero** Apple-specific proprietary information:
  - No Neural Engine architecture or weights
  - No Secure Enclave details
  - No custom accelerators or media engines
  - No undocumented system registers
  - No Apple pipeline or cache geometry data

- **A full-system emulator**  
  It does not model operating systems, devices, I/O, interrupt controllers beyond basic architectural exceptions, or a complete MMU implementation suitable for running a real OS (unlike QEMU).

## Data That Cannot Be Obtained from Public Sources

- Micro-architectural timings (latency / throughput per instruction)
- Cache sizes, associativity, and replacement policies
- Neural Engine weights or internal architecture
- Undocumented system registers or features
- Exact transistor-level or physical design parameters

Die photographs show high-level layout only and do not yield extractable quantitative parameters sufficient for a 1:1 or cycle-accurate simulation.

## Formal Scope Statement

Any generated or extended artifact from this project must remain strictly within the publicly documented Arm AArch64 ISA.  
Claims of “1:1”, “silicon-accurate”, or “Apple Silicon simulation” are explicitly forbidden and infeasible from public information alone.
