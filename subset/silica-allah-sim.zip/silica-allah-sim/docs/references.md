# Public References Only

This project references only publicly available documentation.

## Primary Sources

- Arm Architecture Reference Manual for A-profile architecture  
  (Armv8-A / Armv9-A) — the authoritative public ISA specification.  
  Available from Arm’s developer website under their standard documentation terms.

- Arm Architecture Reference Manual supplements for:
  - SIMD & Floating-point
  - SVE / SVE2
  - SME (where publicly documented)

## Important Notes

- Arm’s Architecture Reference Manuals are **copyrighted**.  
  They are not public-domain documents. Reproduction of substantial portions requires permission from Arm.
- This simulator implements **behavior** described in the public manuals; it does not redistribute the manuals themselves.
- Trademark notice: “Arm” and related marks are trademarks of Arm Limited.  
  This project is not affiliated with or endorsed by Arm.

## Related Open-Source Projects (for comparison)

- QEMU (full-system AArch64 emulation)
- Unicorn Engine (CPU emulation framework)
- LLVM AArch64 backend (encoding/decoding reference)
- Disarm / other lightweight AArch64 decoders

These are independent projects; this repository does not incorporate their code.
