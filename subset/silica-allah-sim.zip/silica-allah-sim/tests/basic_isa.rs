//! Basic integration tests for the ISA-level simulator.

use silica_allah_sim::Cpu;

#[test]
fn runs_nops_and_halts() {
    let mut cpu = Cpu::new();
    cpu.load_program(0x1000, &[0xD503_201F, 0xD503_201F, 0]);
    let steps = cpu.run(10).expect("run should succeed");
    assert!(steps >= 2);
    assert!(cpu.halted);
}

#[test]
fn decoder_handles_common_encodings() {
    use silica_allah_sim::isa::decoder::{DecodedInsn, Decoder};
    let d = Decoder::default();

    assert_eq!(d.decode(0xD503_201F), DecodedInsn::Nop);

    match d.decode(0xD65F_03C0) {
        DecodedInsn::Ret { rn } => assert_eq!(rn, 30),
        other => panic!("unexpected {:?}", other),
    }
}
